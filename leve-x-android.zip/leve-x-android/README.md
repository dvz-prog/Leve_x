# Leve X – o X/Twitter mais leve no Android

App Android que abre o X (x.com) com os recursos da extensão **Leve** embutidos.

| Recurso | O que faz |
| --- | --- |
| Bloquear rastreadores | Corta ~90 domínios de anúncios/monitoramento (mesma lista da extensão). |
| Remover blur | Anula o blur de conteúdo sensível e o aviso, e desliga `filter`/`backdrop-filter`. |
| Imagens maiores | Pedidos de imagem `name=small/tiny/...` são trocados por `name=large`. |
| Reduzir animações | Zera animações e transições CSS. |
| Links de mídia | Botão **🔗 Mídia** no canto inferior esquerdo: links diretos de fotos e vídeos dos posts carregados, com **Baixar** (vai para Downloads/LeveX) e **Copiar**. |
| ⚙ | Liga/desliga cada recurso (botão ao lado do 🔗). |

Links que não são do X abrem no navegador do celular. Android 10 ou superior.

## Como gerar o APK

### Opção A – GitHub Actions (sem instalar nada)
1. Crie um repositório no GitHub e envie esta pasta inteira (incluindo `.github`).
2. Aba **Actions** → execute **Build APK** (roda sozinho a cada push).
3. Ao terminar, baixe o artefato **LeveX-apk** e instale `app-debug.apk` no celular
   (permita "instalar apps desconhecidos").

### Opção B – Android Studio
1. **File → Open** e escolha esta pasta; aguarde o sync do Gradle.
2. **Build → Build APK(s)**, ou conecte o celular e clique em ▶ Run.

### Opção C – linha de comando
Com JDK 17 e o Android SDK instalados (`ANDROID_HOME` definido):

    ./gradlew assembleDebug

O APK sai em `app/build/outputs/apk/debug/app-debug.apk`.

## Notas
- O login usa usuário e senha do X dentro do app. "Entrar com Google" não funciona em WebView.
- Notificações push do X não existem aqui (é o site, não o app oficial).
- Ícone: o mesmo da extensão. Para trocar, substitua `app/src/main/res/mipmap-*/ic_launcher.png`.
