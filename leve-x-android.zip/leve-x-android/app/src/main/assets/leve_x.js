// Leve X – script injetado no x.com / twitter.com antes de a página carregar.
// Junta o que a extensão fazia no X: remover blur, reduzir animações e painel de links de mídia.
// A configuração vem de window.__LEVE_CFG (definida pelo app) e a ponte nativa de window.LeveNative.
(() => {
  if (window.top !== window || window.__leveX) return;
  window.__leveX = true;

  const cfg = Object.assign({ noAnimations: true, noBlur: true, mediaLinks: true }, window.__LEVE_CFG || {});
  const N = window.LeveNative || null;
  const STYLE_ID = 'leve-style';
  const X_STYLE_ID = 'leve-x-unblur';

  /* ---------- Estilos: animações e desfoque ---------- */
  function buildCss() {
    let css = '';
    if (cfg.noAnimations) {
      css +=
        '*,*::before,*::after{' +
        'animation-duration:.001ms!important;animation-delay:0s!important;' +
        'animation-iteration-count:1!important;' +
        'transition-duration:.001ms!important;transition-delay:0s!important;' +
        'scroll-behavior:auto!important}';
    }
    if (cfg.noBlur) {
      css +=
        '*:not(#_leve),*:not(#_leve)::before,*:not(#_leve)::after,::backdrop{' +
        'filter:none!important;' +
        'backdrop-filter:none!important;-webkit-backdrop-filter:none!important}';
    }
    return css;
  }

  function ensureStyle() {
    const css = buildCss();
    const parent = document.head || document.documentElement;
    if (!css || !parent) return; // no início do documento ainda pode não existir
    let el = document.getElementById(STYLE_ID);
    if (!el) {
      el = document.createElement('style');
      el.id = STYLE_ID;
      el.textContent = css;
      parent.appendChild(el);
    }
  }
  (function early() {
    if (document.documentElement) ensureStyle();
    else setTimeout(early, 5);
  })();
  // o X (SPA) pode reconstruir o <head>; garante que o estilo continua lá
  setInterval(ensureStyle, 3000);

  /* ---------- Blur de conteúdo sensível: acha as regras do próprio X e anula ---------- */
  const xDone = new Set();
  const xCounts = new WeakMap();

  function xSheet() {
    let el = document.getElementById(X_STYLE_ID);
    if (!el) {
      const parent = document.head || document.documentElement;
      if (!parent) return null;
      el = document.createElement('style');
      el.id = X_STYLE_ID;
      parent.appendChild(el);
    }
    return el.sheet;
  }

  function xAdd(own, sel, radius, isBackdrop) {
    if (!sel || xDone.has(sel)) return;
    xDone.add(sel);
    try {
      own.insertRule(
        sel + '{filter:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}',
        own.cssRules.length
      );
    } catch (_) {}
    if (!isBackdrop && radius >= 20 && sel.indexOf('(') === -1) {
      const list = sel.split(',').map((x) => x.trim() + '+div').join(',');
      try {
        own.insertRule(list + '{display:none!important}', own.cssRules.length);
      } catch (_) {}
    }
  }

  function xWalk(own, rules) {
    for (let i = 0; i < rules.length; i++) {
      const r = rules[i];
      if (r.selectorText !== undefined && r.style) {
        const f = r.style.getPropertyValue('filter');
        const b = r.style.getPropertyValue('backdrop-filter') || r.style.getPropertyValue('-webkit-backdrop-filter');
        const fm = f && /blur\(\s*([\d.]+)/i.exec(f);
        const bm = b && /blur\(\s*([\d.]+)/i.exec(b);
        if (fm) xAdd(own, r.selectorText, parseFloat(fm[1]), false);
        else if (bm) xAdd(own, r.selectorText, parseFloat(bm[1]), true);
      } else if (r.cssRules) {
        xWalk(own, r.cssRules);
      }
    }
  }

  function xScan() {
    if (document.hidden) return;
    const own = xSheet();
    if (!own) return;
    for (const ss of document.styleSheets) {
      const owner = ss.ownerNode;
      if (owner && (owner.id === STYLE_ID || owner.id === X_STYLE_ID)) continue;
      let rules;
      try {
        rules = ss.cssRules;
      } catch (_) {
        continue;
      }
      if (xCounts.get(ss) === rules.length) continue;
      xCounts.set(ss, rules.length);
      xWalk(own, rules);
    }
  }

  if (cfg.noBlur) setInterval(xScan, 1500);

  /* ---------- Links diretos de mídia: lê as respostas da API do X ---------- */
  const API = /\/i\/api\/(graphql|1\.1|2)\//;
  const OK_URL = /^https:\/\/(video|pbs)\.twimg\.com\//;
  const mediaMap = new Map();
  let queued = false;

  function screenName(t) {
    const r = t.core && t.core.user_results && t.core.user_results.result;
    return (r && ((r.core && r.core.screen_name) || (r.legacy && r.legacy.screen_name))) || '';
  }

  function build(t) {
    const l = t.legacy;
    const list = (l.extended_entities && l.extended_entities.media) || (l.entities && l.entities.media);
    if (!list || !list.length) return null;
    const media = [];
    for (const m of list) {
      if (m.type === 'photo' && m.media_url_https) {
        media.push({ t: 'photo', urls: [{ u: m.media_url_https + '?name=orig', l: 'original' }] });
      } else if (m.video_info && m.video_info.variants) {
        const urls = m.video_info.variants
          .filter((v) => v.content_type === 'video/mp4' && v.url)
          .sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))
          .map((v) => {
            const r = /\/(\d+x\d+)\//.exec(v.url);
            return { u: v.url, l: r ? r[1] : 'mp4' };
          });
        if (urls.length) media.push({ t: m.type === 'animated_gif' ? 'gif' : 'video', urls });
      }
    }
    if (!media.length) return null;
    return { id: t.rest_id, user: screenName(t), text: String(l.full_text || '').slice(0, 140), media };
  }

  function collect(root) {
    const out = new Map();
    const stack = [root];
    let n = 0;
    while (stack.length && n++ < 300000) {
      const o = stack.pop();
      if (!o || typeof o !== 'object') continue;
      if (Array.isArray(o)) {
        for (const x of o) stack.push(x);
        continue;
      }
      if (o.rest_id && o.legacy) {
        const item = build(o);
        if (item) out.set(item.id, item);
      }
      for (const k in o) {
        const v = o[k];
        if (v && typeof v === 'object') stack.push(v);
      }
    }
    return [...out.values()];
  }

  function ingest(items) {
    for (const it of items) {
      const media = [];
      for (const m of it.media) {
        const urls = m.urls.filter((x) => OK_URL.test(x.u));
        if (urls.length) media.push({ t: m.t, urls });
      }
      if (!media.length) continue;
      mediaMap.delete(it.id);
      mediaMap.set(it.id, { id: it.id, user: it.user, text: it.text, media });
      if (mediaMap.size > 300) mediaMap.delete(mediaMap.keys().next().value);
    }
    queueRender();
  }

  function handle(data) {
    setTimeout(() => {
      try {
        const items = collect(data);
        if (items.length) ingest(items);
      } catch (_) {}
    }, 0);
  }

  if (cfg.mediaLinks) {
    const origFetch = window.fetch;
    window.fetch = function (...args) {
      const p = origFetch.apply(this, args);
      try {
        const u = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
        if (API.test(u)) p.then((r) => r.clone().json().then(handle, () => {}), () => {});
      } catch (_) {}
      return p;
    };

    const origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (m, u) {
      try {
        this.__leveUrl = String(u);
      } catch (_) {}
      return origOpen.apply(this, arguments);
    };
    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function () {
      if (API.test(this.__leveUrl || '')) {
        this.addEventListener('load', () => {
          try {
            if (this.responseType === '' || this.responseType === 'text') handle(JSON.parse(this.responseText));
            else if (this.responseType === 'json') handle(this.response);
          } catch (_) {}
        });
      }
      return origSend.apply(this, arguments);
    };
  }

  /* ---------- Botões flutuantes: ⚙ configurações e 🔗 links de mídia ---------- */
  let panel = null;
  let panelOpen = false;

  function mk(tag, props, kids) {
    const el = document.createElement(tag);
    Object.assign(el, props || {});
    (kids || []).forEach((k) => el.appendChild(typeof k === 'string' ? document.createTextNode(k) : k));
    return el;
  }

  function copyText(text, btn) {
    const done = () => {
      btn.textContent = 'Copiado ✓';
      setTimeout(() => (btn.textContent = 'Copiar'), 1200);
    };
    if (N && N.copy) {
      N.copy(text);
      done();
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(done, () => {});
    }
  }

  function ensurePanel() {
    if (panel) return panel;
    const host = mk('div');
    host.id = 'leve-media-host';
    host.style.cssText = 'all:initial;position:fixed;left:10px;bottom:76px;z-index:2147483647;';
    const root = host.attachShadow({ mode: 'open' });
    root.appendChild(
      mk('style', {
        textContent:
          '*{box-sizing:border-box;font:14px/1.4 system-ui,sans-serif}' +
          '.bar{display:flex;gap:6px;align-items:center}' +
          '.btn{background:#1f9d6b;color:#fff;border:0;border-radius:999px;padding:9px 14px;font-weight:600;box-shadow:0 2px 10px #0006}' +
          '.gear{background:#151b18;color:#e8efeb;border:1px solid #2a352f;border-radius:999px;width:38px;height:38px;padding:0;opacity:.75;font-size:17px}' +
          '.box{width:min(360px,calc(100vw - 20px));max-height:55vh;overflow:auto;background:#151b18;color:#e8efeb;border:1px solid #2a352f;border-radius:12px;padding:8px;margin-bottom:8px;box-shadow:0 4px 18px #0008}' +
          '.it{border-bottom:1px solid #2a352f;padding:8px 4px}.it:last-child{border:0}' +
          '.who{font-weight:700;color:#34c48a}.txt{color:#93a39a;font-size:12px;margin:2px 0 6px;word-break:break-word}' +
          '.l{display:flex;gap:6px;align-items:center;margin:4px 0}' +
          '.l span{flex:1;background:#1d2621;border-radius:6px;padding:6px 8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
          '.l button{background:#2a352f;color:#e8efeb;border:0;border-radius:6px;padding:6px 9px}' +
          '.l button.dl{background:#1f9d6b;color:#fff}' +
          '.empty{padding:12px;color:#93a39a}'
      })
    );
    const box = mk('div', { className: 'box' });
    box.hidden = true;
    const bar = mk('div', { className: 'bar' });
    const gear = mk('button', { className: 'gear', type: 'button', textContent: '⚙', title: 'Configurações do Leve' });
    gear.addEventListener('click', () => {
      if (N && N.openSettings) N.openSettings();
    });
    const btn = mk('button', { className: 'btn', type: 'button' });
    btn.addEventListener('click', () => {
      panelOpen = !panelOpen;
      renderPanel();
    });
    bar.appendChild(gear);
    if (cfg.mediaLinks) bar.appendChild(btn);
    root.appendChild(box);
    root.appendChild(bar);
    (document.body || document.documentElement).appendChild(host);
    panel = { host, box, btn };
    return panel;
  }

  function queueRender() {
    if (queued) return;
    queued = true;
    setTimeout(() => {
      queued = false;
      renderPanel();
    }, 300);
  }

  function renderPanel() {
    if (!document.body) return;
    const p = ensurePanel();
    if (!p.host.isConnected) document.body.appendChild(p.host);
    if (!cfg.mediaLinks) return;
    p.btn.textContent = '🔗 Mídia (' + mediaMap.size + ')';
    p.box.hidden = !panelOpen;
    if (!panelOpen) return;

    const cur = (/\/status\/(\d+)/.exec(location.pathname) || [])[1];
    const items = [...mediaMap.values()].reverse();
    if (cur) items.sort((a, b) => (b.id === cur) - (a.id === cur));

    p.box.textContent = '';
    if (!items.length) {
      p.box.appendChild(mk('div', { className: 'empty', textContent: 'Role o feed: os links aparecem aqui conforme os posts carregam.' }));
      return;
    }
    for (const it of items.slice(0, 60)) {
      const row = mk('div', { className: 'it' });
      row.appendChild(mk('div', { className: 'who', textContent: it.user ? '@' + it.user : 'post ' + it.id }));
      if (it.text) row.appendChild(mk('div', { className: 'txt', textContent: it.text }));
      for (const m of it.media) {
        const name = m.t === 'photo' ? 'Foto' : m.t === 'gif' ? 'GIF' : 'Vídeo';
        m.urls.forEach((x, i) => {
          if (i > 2) return;
          const label = mk('span', { textContent: name + ' · ' + x.l, title: x.u });
          const dl = mk('button', { type: 'button', className: 'dl', textContent: 'Baixar' });
          dl.addEventListener('click', () => {
            if (N && N.download) N.download(x.u);
          });
          const c = mk('button', { type: 'button', textContent: 'Copiar' });
          c.addEventListener('click', () => copyText(x.u, c));
          row.appendChild(mk('div', { className: 'l' }, [label, dl, c]));
        });
      }
      p.box.appendChild(row);
    }
  }

  const boot = () => renderPanel();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
  // o X troca o <body> ao navegar: garante que os botões voltem
  setInterval(() => {
    if (document.body && (!panel || !panel.host.isConnected)) renderPanel();
  }, 2000);
})();
