// Leve X – script injetado no x.com / twitter.com antes de a página carregar.
// Junta o que a extensão fazia no X: remover blur, reduzir animações e painel de links de mídia.
// A configuração vem de window.__LEVE_CFG (definida pelo app) e a ponte nativa de window.LeveNative.
(() => {
  if (window.top !== window || window.__leveX) return;
  window.__leveX = true;

  const cfg = Object.assign({ noAnimations: true, noBlur: true, mediaLinks: true, profileMedia: true }, window.__LEVE_CFG || {});
  const N = window.LeveNative || null;
  const STYLE_ID = 'leve-style';
  const X_STYLE_ID = 'leve-x-unblur';

  /* ---------- Estilos: animações e desfoque ---------- */
  function buildCss() {
    let css = '';
    if (cfg.noAnimations) {
      css +=
        '*,*::before,*::after{' +
        'animation-duration:.001ms!important;animation-delay:0s!important;' +
        'animation-iteration-count:1!important;' +
        'transition-duration:.001ms!important;transition-delay:0s!important;' +
        'scroll-behavior:auto!important}';
    }
    if (cfg.noBlur) {
      css +=
        '*:not(#_leve),*:not(#_leve)::before,*:not(#_leve)::after,::backdrop{' +
        'filter:none!important;' +
        'backdrop-filter:none!important;-webkit-backdrop-filter:none!important}';
    }
    return css;
  }

  function ensureStyle() {
    const css = buildCss();
    const parent = document.head || document.documentElement;
    if (!css || !parent) return; // no início do documento ainda pode não existir
    let el = document.getElementById(STYLE_ID);
    if (!el) {
      el = document.createElement('style');
      el.id = STYLE_ID;
      el.textContent = css;
      parent.appendChild(el);
    }
  }
  (function early() {
    if (document.documentElement) ensureStyle();
    else setTimeout(early, 5);
  })();
  // o X (SPA) pode reconstruir o <head>; garante que o estilo continua lá
  setInterval(ensureStyle, 3000);

  /* ---------- Blur de conteúdo sensível: acha as regras do próprio X e anula ---------- */
  const xDone = new Set();
  const xCounts = new WeakMap();

  function xSheet() {
    let el = document.getElementById(X_STYLE_ID);
    if (!el) {
      const parent = document.head || document.documentElement;
      if (!parent) return null;
      el = document.createElement('style');
      el.id = X_STYLE_ID;
      parent.appendChild(el);
    }
    return el.sheet;
  }

  function xAdd(own, sel, radius, isBackdrop) {
    if (!sel || xDone.has(sel)) return;
    xDone.add(sel);
    try {
      own.insertRule(
        sel + '{filter:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important}',
        own.cssRules.length
      );
    } catch (_) {}
    if (!isBackdrop && radius >= 20 && sel.indexOf('(') === -1) {
      const list = sel.split(',').map((x) => x.trim() + '+div').join(',');
      try {
        own.insertRule(list + '{display:none!important}', own.cssRules.length);
      } catch (_) {}
    }
  }

  function xWalk(own, rules) {
    for (let i = 0; i < rules.length; i++) {
      const r = rules[i];
      if (r.selectorText !== undefined && r.style) {
        const f = r.style.getPropertyValue('filter');
        const b = r.style.getPropertyValue('backdrop-filter') || r.style.getPropertyValue('-webkit-backdrop-filter');
        const fm = f && /blur\(\s*([\d.]+)/i.exec(f);
        const bm = b && /blur\(\s*([\d.]+)/i.exec(b);
        if (fm) xAdd(own, r.selectorText, parseFloat(fm[1]), false);
        else if (bm) xAdd(own, r.selectorText, parseFloat(bm[1]), true);
      } else if (r.cssRules) {
        xWalk(own, r.cssRules);
      }
    }
  }

  function xScan() {
    if (document.hidden) return;
    const own = xSheet();
    if (!own) return;
    for (const ss of document.styleSheets) {
      const owner = ss.ownerNode;
      if (owner && (owner.id === STYLE_ID || owner.id === X_STYLE_ID)) continue;
      let rules;
      try {
        rules = ss.cssRules;
      } catch (_) {
        continue;
      }
      if (xCounts.get(ss) === rules.length) continue;
      xCounts.set(ss, rules.length);
      xWalk(own, rules);
    }
  }

  if (cfg.noBlur) setInterval(xScan, 1500);

  /* ---------- Links diretos de mídia: lê as respostas da API do X ---------- */
  const API = /\/i\/api\/(graphql|1\.1|2)\//;
  const OK_URL = /^https:\/\/(video|pbs)\.twimg\.com\//;
  const mediaMap = new Map();
  let queued = false;

  function screenName(t) {
    const r = t.core && t.core.user_results && t.core.user_results.result;
    return (r && ((r.core && r.core.screen_name) || (r.legacy && r.legacy.screen_name))) || '';
  }

  function build(t) {
    const l = t.legacy;
    const list = (l.extended_entities && l.extended_entities.media) || (l.entities && l.entities.media);
    if (!list || !list.length) return null;
    const media = [];
    for (const m of list) {
      if (m.type === 'photo' && m.media_url_https) {
        media.push({ t: 'photo', urls: [{ u: m.media_url_https + '?name=orig', l: 'original' }] });
      } else if (m.video_info && m.video_info.variants) {
        const urls = m.video_info.variants
          .filter((v) => v.content_type === 'video/mp4' && v.url)
          .sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0))
          .map((v) => {
            const r = /\/(\d+x\d+)\//.exec(v.url);
            return { u: v.url, l: r ? r[1] : 'mp4' };
          });
        if (urls.length) media.push({ t: m.type === 'animated_gif' ? 'gif' : 'video', urls });
      }
    }
    if (!media.length) return null;
    return { id: t.rest_id, user: screenName(t), text: String(l.full_text || '').slice(0, 140), media };
  }

  function collect(root) {
    const out = new Map();
    const stack = [root];
    let n = 0;
    while (stack.length && n++ < 300000) {
      const o = stack.pop();
      if (!o || typeof o !== 'object') continue;
      if (Array.isArray(o)) {
        for (const x of o) stack.push(x);
        continue;
      }
      if (o.rest_id && o.legacy) {
        const item = build(o);
        if (item) out.set(item.id, item);
      }
      for (const k in o) {
        const v = o[k];
        if (v && typeof v === 'object') stack.push(v);
      }
    }
    return [...out.values()];
  }

  function ingest(items) {
    for (const it of items) {
      const media = [];
      for (const m of it.media) {
        const urls = m.urls.filter((x) => OK_URL.test(x.u));
        if (urls.length) media.push({ t: m.t, urls });
      }
      if (!media.length) continue;
      mediaMap.delete(it.id);
      mediaMap.set(it.id, { id: it.id, user: it.user, text: it.text, media });
      if (mediaMap.size > 300) mediaMap.delete(mediaMap.keys().next().value);
    }
    queueRender();
  }

  function handle(data) {
    setTimeout(() => {
      try {
        const items = collect(data);
        if (items.length) ingest(items);
      } catch (_) {}
    }, 0);
  }

  if (cfg.mediaLinks) {
    const origFetch = window.fetch;
    window.fetch = function (...args) {
      const p = origFetch.apply(this, args);
      try {
        const u = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
        if (API.test(u)) p.then((r) => r.clone().json().then(handle, () => {}), () => {});
      } catch (_) {}
      return p;
    };

    const origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (m, u) {
      try {
        this.__leveUrl = String(u);
      } catch (_) {}
      return origOpen.apply(this, arguments);
    };
    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.send = function () {
      if (API.test(this.__leveUrl || '')) {
        this.addEventListener('load', () => {
          try {
            if (this.responseType === '' || this.responseType === 'text') handle(JSON.parse(this.responseText));
            else if (this.responseType === 'json') handle(this.response);
          } catch (_) {}
        });
      }
      return origSend.apply(this, arguments);
    };
  }

  /* ---------- Botões flutuantes: ⚙ configurações e 🔗 links de mídia ---------- */
  let panel = null;
  let panelOpen = false;

  function mk(tag, props, kids) {
    const el = document.createElement(tag);
    Object.assign(el, props || {});
    (kids || []).forEach((k) => el.appendChild(typeof k === 'string' ? document.createTextNode(k) : k));
    return el;
  }

  function copyText(text, btn) {
    const done = () => {
      btn.textContent = 'Copiado ✓';
      setTimeout(() => (btn.textContent = 'Copiar'), 1200);
    };
    if (N && N.copy) {
      N.copy(text);
      done();
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(done, () => {});
    }
  }

  function ensurePanel() {
    if (panel) return panel;
    const host = mk('div');
    host.id = 'leve-media-host';
    host.style.cssText = 'all:initial;position:fixed;left:10px;bottom:76px;z-index:2147483647;';
    const root = host.attachShadow({ mode: 'open' });
    root.appendChild(
      mk('style', {
        textContent:
          '*{box-sizing:border-box;font:14px/1.4 system-ui,sans-serif}' +
          '.bar{display:flex;gap:6px;align-items:center}' +
          '.btn{background:#1f9d6b;color:#fff;border:0;border-radius:999px;padding:9px 14px;font-weight:600;box-shadow:0 2px 10px #0006}' +
          '.gear{background:#151b18;color:#e8efeb;border:1px solid #2a352f;border-radius:999px;width:38px;height:38px;padding:0;opacity:.75;font-size:17px}' +
          '.box{width:min(360px,calc(100vw - 20px));max-height:55vh;overflow:auto;background:#151b18;color:#e8efeb;border:1px solid #2a352f;border-radius:12px;padding:8px;margin-bottom:8px;box-shadow:0 4px 18px #0008}' +
          '.it{border-bottom:1px solid #2a352f;padding:8px 4px}.it:last-child{border:0}' +
          '.who{font-weight:700;color:#34c48a}.txt{color:#93a39a;font-size:12px;margin:2px 0 6px;word-break:break-word}' +
          '.l{display:flex;gap:6px;align-items:center;margin:4px 0}' +
          '.l span{flex:1;background:#1d2621;border-radius:6px;padding:6px 8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
          '.l button{background:#2a352f;color:#e8efeb;border:0;border-radius:6px;padding:6px 9px}' +
          '.l button.dl{background:#1f9d6b;color:#fff}' +
          '.empty{padding:12px;color:#93a39a}' +
          '.pb{display:flex;gap:6px;flex-wrap:wrap;align-items:center;padding:2px 4px 8px;border-bottom:1px solid #2a352f}' +
          '.pb b{flex:1 1 100%;color:#34c48a}' +
          '.pb button{background:#1f9d6b;color:#fff;border:0;border-radius:6px;padding:7px 10px}' +
          '.pb button.off{background:#2a352f;color:#e8efeb}'
      })
    );
    const box = mk('div', { className: 'box' });
    box.hidden = true;
    const bar = mk('div', { className: 'bar' });
    const gear = mk('button', { className: 'gear', type: 'button', textContent: '⚙', title: 'Configurações do Leve' });
    gear.addEventListener('click', () => {
      if (N && N.openSettings) N.openSettings();
    });
    const btn = mk('button', { className: 'btn', type: 'button' });
    btn.addEventListener('click', () => {
      panelOpen = !panelOpen;
      renderPanel();
    });
    bar.appendChild(gear);
    if (cfg.mediaLinks) bar.appendChild(btn);
    root.appendChild(box);
    root.appendChild(bar);
    (document.body || document.documentElement).appendChild(host);
    panel = { host, box, btn };
    return panel;
  }

  function queueRender() {
    if (queued) return;
    queued = true;
    setTimeout(() => {
      queued = false;
      renderPanel();
    }, 300);
  }

  function renderPanel() {
    if (!document.body) return;
    const p = ensurePanel();
    if (!p.host.isConnected) document.body.appendChild(p.host);
    if (!cfg.mediaLinks) return;
    const user = viewUser(location.pathname);
    p.btn.hidden = !user; // fora de um perfil o botão de mídia some
    p.btn.textContent = '🔗 Mídia (' + (user ? profItems(user).length : 0) + ')';
    p.box.hidden = !panelOpen || !user;
    if (p.box.hidden) return;

    const cur = (/\/status\/(\d+)/.exec(location.pathname) || [])[1];
    const prof = profileOf(location.pathname);
    const items = profItems(user);
    if (cur) items.sort((a, b) => (b.id === cur) - (a.id === cur));

    p.box.textContent = '';
    if (prof) p.box.appendChild(profileBar(prof, items));
    if (!items.length) {
      p.box.appendChild(mk('div', { className: 'empty', textContent: 'Role o perfil: os links de fotos e vídeos dele aparecem aqui conforme os posts carregam.' }));
      return;
    }
    for (const it of items.slice(0, prof ? 150 : 60)) {
      const row = mk('div', { className: 'it' });
      row.appendChild(mk('div', { className: 'who', textContent: it.user ? '@' + it.user : 'post ' + it.id }));
      if (it.text) row.appendChild(mk('div', { className: 'txt', textContent: it.text }));
      for (const m of it.media) {
        const name = m.t === 'photo' ? 'Foto' : m.t === 'gif' ? 'GIF' : 'Vídeo';
        m.urls.forEach((x, i) => {
          if (i > 2) return;
          const label = mk('span', { textContent: name + ' · ' + x.l, title: x.u });
          const dl = mk('button', { type: 'button', className: 'dl', textContent: 'Baixar' });
          dl.addEventListener('click', () => {
            if (N && N.download) N.download(x.u);
          });
          const c = mk('button', { type: 'button', textContent: 'Copiar' });
          c.addEventListener('click', () => copyText(x.u, c));
          row.appendChild(mk('div', { className: 'l' }, [label, dl, c]));
        });
      }
      p.box.appendChild(row);
    }
  }


  /* ---------- Modo perfil: abre direto a aba Mídia e mostra só a mídia do perfil ---------- */
  const RESERVED = new Set(['home', 'explore', 'notifications', 'messages', 'i', 'settings', 'search',
    'compose', 'login', 'logout', 'signup', 'tos', 'privacy', 'about', 'jobs', 'hashtag', 'intent',
    'share', 'account', 'download', 'following', 'followers', 'lists', 'bookmarks', 'premium']);

  // perfil da página atual (raiz ou abas), em minúsculas; null se não for perfil
  function profileOf(path) {
    const m = /^\/([A-Za-z0-9_]{1,15})(?:\/(?:media|with_replies|highlights|articles|likes|superfollows))?\/?$/.exec(path);
    return m && !RESERVED.has(m[1].toLowerCase()) ? m[1].toLowerCase() : null;
  }

  function profileRoot(path) {
    const m = /^\/([A-Za-z0-9_]{1,15})\/?$/.exec(path);
    return m && !RESERVED.has(m[1].toLowerCase()) ? m[1] : null;
  }

  // perfil em exibição: página de perfil (raiz/abas) ou o autor do post aberto (/perfil/status/ID)
  function viewUser(path) {
    const p = profileOf(path);
    if (p) return p;
    const m = /^\/([A-Za-z0-9_]{1,15})\/status\/\d+/.exec(path);
    return m && !RESERVED.has(m[1].toLowerCase()) ? m[1].toLowerCase() : null;
  }

  let viewed; // perfil em exibição na última checagem

  function profItems(prof) {
    return [...mediaMap.values()].reverse().filter((it) => (it.user || '').toLowerCase() === prof);
  }

  let lastPath = '';
  let pending = null;
  let loadAll = null;
  let confirmAll = false;

  function onPathChange(p, prev) {
    const vu = viewUser(p);
    if (vu !== viewed) {
      viewed = vu;
      // trocou de perfil (ou saiu de perfis): os links do perfil anterior somem
      for (const [id, it] of mediaMap) {
        if (String(it.user || '').toLowerCase() !== vu) mediaMap.delete(id);
      }
    }
    pending = null;
    confirmAll = false;
    if (loadAll) stopLoadAll();
    const u = cfg.profileMedia && profileRoot(p);
    // não redireciona quando o usuário volta da aba Mídia (senão não dá para sair)
    if (u && !prev.toLowerCase().startsWith('/' + u.toLowerCase() + '/')) {
      pending = { u, start: Date.now() };
    }
    queueRender();
  }

  setInterval(() => {
    const p = location.pathname;
    if (p !== lastPath) {
      const prev = lastPath;
      lastPath = p;
      onPathChange(p, prev);
    }
    if (pending) {
      if (profileRoot(location.pathname) !== pending.u) {
        pending = null;
        return;
      }
      const sel = 'a[href="/' + pending.u + '/media" i]';
      const a = document.querySelector(sel);
      if (a) {
        pending = null;
        a.click();
      } else if (Date.now() - pending.start > 3000) {
        const u = pending.u;
        pending = null;
        location.assign('/' + u + '/media');
      }
    }
  }, 400);

  function stopLoadAll() {
    if (loadAll) clearInterval(loadAll.t);
    loadAll = null;
    queueRender();
  }

  function toggleLoadAll(prof) {
    if (loadAll) return stopLoadAll();
    let last = -1;
    let same = 0;
    loadAll = {
      t: setInterval(() => {
        window.scrollTo(0, document.documentElement.scrollHeight);
        const n = profItems(prof).length;
        if (n === last) {
          if (++same >= 5) stopLoadAll(); // nada novo: chegou ao fim
        } else {
          same = 0;
          last = n;
        }
      }, 1200)
    };
    queueRender();
  }

  function downloadAll(items) {
    if (!N || !N.download) return;
    const urls = [];
    items.forEach((it) => it.media.forEach((m) => m.urls[0] && urls.push(m.urls[0].u)));
    let i = 0;
    (function next() {
      if (i >= urls.length) return;
      N.download(urls[i++]);
      setTimeout(next, 400);
    })();
  }

  function profileBar(prof, items) {
    let files = 0;
    items.forEach((it) => (files += it.media.length));
    const bar = mk('div', { className: 'pb' });
    bar.appendChild(mk('b', { textContent: '@' + prof + ' · ' + items.length + ' posts · ' + files + ' arquivos' }));
    const all = mk('button', { type: 'button', textContent: loadAll ? 'Parar' : 'Carregar tudo', className: loadAll ? 'off' : '' });
    all.addEventListener('click', () => toggleLoadAll(prof));
    const dl = mk('button', {
      type: 'button',
      textContent: confirmAll ? 'Confirmar: baixar ' + files : 'Baixar todos',
      className: confirmAll ? '' : 'off'
    });
    dl.addEventListener('click', () => {
      if (!files) return;
      if (!confirmAll) {
        confirmAll = true;
        renderPanel();
        return;
      }
      confirmAll = false;
      downloadAll(items);
      renderPanel();
    });
    bar.appendChild(all);
    bar.appendChild(dl);
    return bar;
  }

  lastPath = '';

  const boot = () => renderPanel();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
  // o X troca o <body> ao navegar: garante que os botões voltem
  setInterval(() => {
    if (document.body && (!panel || !panel.host.isConnected)) renderPanel();
  }, 2000);
})();
