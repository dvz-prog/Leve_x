package com.leve.x;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONArray;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Leve X: o X/Twitter dentro de um WebView, com os recursos da extensão "Leve":
 * bloqueio de rastreadores, imagens maiores, remoção de blur, menos animações
 * e painel de links diretos de mídia.
 */
public class MainActivity extends Activity {
    private static final String HOME = "https://x.com/";
    private static final int REQ_FILE = 1001;

    private static final Set<String> ORIGINS = new HashSet<>(Arrays.asList(
            "https://x.com", "https://twitter.com", "https://mobile.twitter.com"));
    private static final Set<String> SMALL_NAMES = new HashSet<>(Arrays.asList(
            "tiny", "thumb", "small", "medium", "120x120", "240x240", "360x360", "900x900"));

    private WebView web;
    private FrameLayout root;
    private SharedPreferences prefs;

    // lidas também por threads de rede do WebView
    private volatile boolean blockTrackers = true;
    private volatile boolean noBlur = true;
    private boolean noAnimations = true;
    private boolean mediaLinks = true;

    private final Set<String> trackerDomains = new HashSet<>();
    private String leveJs = "";
    private String fullScript = "";
    private ScriptHandler scriptHandler;
    private boolean docStartSupported = false;
    private String userAgent;

    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private ValueCallback<Uri[]> fileCallback;
    private LeveChrome chrome;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("leve", MODE_PRIVATE);
        loadPrefs();
        loadTrackers();
        leveJs = readAsset("leve_x.js");

        root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // tira "; wv" e "Version/4.0" para o X servir o site normal de celular
        userAgent = WebSettings.getDefaultUserAgent(this)
                .replace("; wv)", ")").replace(" Version/4.0", "");
        s.setUserAgentString(userAgent);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new Bridge(), "LeveNative");
        web.setWebViewClient(new LeveClient());
        chrome = new LeveChrome();
        web.setWebChromeClient(chrome);

        docStartSupported = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        registerScript();

        web.loadUrl(urlFromIntent(getIntent()));
    }

    /* ---------------- Configurações ---------------- */

    private void loadPrefs() {
        blockTrackers = prefs.getBoolean("blockTrackers", true);
        noBlur = prefs.getBoolean("noBlur", true);
        noAnimations = prefs.getBoolean("noAnimations", true);
        mediaLinks = prefs.getBoolean("mediaLinks", true);
    }

    private void showSettings() {
        final String[] labels = {
                "Bloquear rastreadores",
                "Remover blur e usar imagens maiores",
                "Reduzir animações",
                "Painel de links de mídia"
        };
        final boolean[] checked = {blockTrackers, noBlur, noAnimations, mediaLinks};
        new AlertDialog.Builder(this)
                .setTitle("Leve X")
                .setMultiChoiceItems(labels, checked, (d, i, c) -> checked[i] = c)
                .setPositiveButton("Aplicar e recarregar", (d, w) -> {
                    prefs.edit()
                            .putBoolean("blockTrackers", checked[0])
                            .putBoolean("noBlur", checked[1])
                            .putBoolean("noAnimations", checked[2])
                            .putBoolean("mediaLinks", checked[3])
                            .apply();
                    loadPrefs();
                    registerScript();
                    web.reload();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /* ---------------- Script injetado ---------------- */

    private void registerScript() {
        String cfg = "{\"noAnimations\":" + noAnimations
                + ",\"noBlur\":" + noBlur
                + ",\"mediaLinks\":" + mediaLinks + "}";
        fullScript = "window.__LEVE_CFG=" + cfg + ";\n" + leveJs;
        if (docStartSupported) {
            if (scriptHandler != null) scriptHandler.remove();
            scriptHandler = WebViewCompat.addDocumentStartJavaScript(web, fullScript, ORIGINS);
        }
    }

    /* ---------------- Rastreadores ---------------- */

    private void loadTrackers() {
        try {
            JSONArray arr = new JSONArray(readAsset("trackers.json"));
            for (int i = 0; i < arr.length(); i++) trackerDomains.add(arr.getString(i));
        } catch (Exception ignored) {
        }
    }

    private boolean isTracker(Uri u) {
        String host = u.getHost();
        if (host == null) return false;
        host = host.toLowerCase();
        for (String h = host; h != null; ) {
            if (trackerDomains.contains(h)) return true;
            int i = h.indexOf('.');
            if (i < 0) break;
            h = h.substring(i + 1);
        }
        String path = u.getPath() == null ? "" : u.getPath();
        if ((host.equals("facebook.com") || host.endsWith(".facebook.com"))
                && (path.equals("/tr") || path.startsWith("/tr/"))) return true;
        if (host.equals("connect.facebook.net") && path.endsWith("/fbevents.js")) return true;
        return host.equals("snap.licdn.com") && path.startsWith("/li.lms-analytics");
    }

    /* ---------------- Imagens maiores ---------------- */

    private WebResourceResponse largerImage(Uri u) {
        String name = u.getQueryParameter("name");
        String path = u.getPath();
        if (name == null || path == null || !path.startsWith("/media/") || !SMALL_NAMES.contains(name)) {
            return null;
        }
        HttpURLConnection c = null;
        try {
            Uri.Builder b = u.buildUpon().clearQuery();
            for (String k : u.getQueryParameterNames()) {
                for (String v : u.getQueryParameters(k)) {
                    b.appendQueryParameter(k, k.equals("name") ? "large" : v);
                }
            }
            c = (HttpURLConnection) new URL(b.build().toString()).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(15000);
            c.setRequestProperty("User-Agent", userAgent);
            if (c.getResponseCode() != 200) {
                c.disconnect();
                return null;
            }
            String mime = c.getContentType();
            if (mime == null) mime = "image/jpeg";
            int semi = mime.indexOf(';');
            if (semi > 0) mime = mime.substring(0, semi).trim();
            Map<String, String> headers = new HashMap<>();
            headers.put("Access-Control-Allow-Origin", "*");
            headers.put("Cache-Control", "max-age=86400");
            return new WebResourceResponse(mime, null, 200, "OK", headers, c.getInputStream());
        } catch (Exception e) {
            if (c != null) c.disconnect();
            return null; // deixa o WebView carregar o original
        }
    }

    /* ---------------- Navegação ---------------- */

    private static boolean isXHost(String host) {
        if (host == null) return false;
        host = host.toLowerCase();
        return host.equals("x.com") || host.endsWith(".x.com")
                || host.equals("twitter.com") || host.endsWith(".twitter.com");
    }

    private String urlFromIntent(Intent i) {
        if (i != null && i.getData() != null) {
            Uri d = i.getData();
            if ("https".equals(d.getScheme()) && isXHost(d.getHost())) return d.toString();
        }
        return HOME;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getData() != null) web.loadUrl(urlFromIntent(intent));
    }

    private class LeveClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            if (!req.isForMainFrame()) return false;
            Uri u = req.getUrl();
            String scheme = u.getScheme() == null ? "" : u.getScheme();
            boolean isHttp = scheme.equals("http") || scheme.equals("https");
            if (isHttp && isXHost(u.getHost())) return false;
            if (isHttp || scheme.equals("mailto") || scheme.equals("tel")
                    || scheme.equals("sms") || scheme.equals("intent") || scheme.equals("market")) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
                return true;
            }
            return false;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (blockTrackers && isTracker(u)) {
                WebResourceResponse r = new WebResourceResponse(
                        "text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
                r.setStatusCodeAndReasonPhrase(403, "Blocked by Leve");
                return r;
            }
            if (noBlur && "GET".equals(req.getMethod()) && "pbs.twimg.com".equals(u.getHost())) {
                return largerImage(u);
            }
            return null;
        }

        @Override
        public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
            // plano B para WebViews antigos sem "script no início do documento"
            if (!docStartSupported && url != null && isXHost(Uri.parse(url).getHost())) {
                view.evaluateJavascript(fullScript, null);
            }
        }
    }

    private class LeveChrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = cb;
            try {
                startActivityForResult(params.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCallback = null;
                return false;
            }
            return true;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customViewCallback = cb;
            web.setVisibility(View.GONE);
            root.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;
            root.removeView(customView);
            customView = null;
            web.setVisibility(View.VISIBLE);
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            if (customViewCallback != null) customViewCallback.onCustomViewHidden();
            customViewCallback = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (customView != null) {
            chrome.onHideCustomView();
        } else if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            root.removeView(web);
            web.destroy();
        }
        super.onDestroy();
    }

    /* ---------------- Ponte JS <-> app ---------------- */

    public class Bridge {
        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(MainActivity.this::showSettings);
        }

        @JavascriptInterface
        public void copy(String text) {
            if (text == null || text.length() > 4000) return;
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Leve X", text));
            });
        }

        @JavascriptInterface
        public void download(String url) {
            runOnUiThread(() -> startDownload(url));
        }
    }

    private void startDownload(String url) {
        try {
            Uri u = Uri.parse(url);
            String host = u.getHost();
            if (!"https".equals(u.getScheme())
                    || !("video.twimg.com".equals(host) || "pbs.twimg.com".equals(host))) return;
            String name = u.getLastPathSegment();
            if (name == null || name.isEmpty()) name = "leve_x_" + System.currentTimeMillis();
            name = name.replaceAll("[^A-Za-z0-9._-]", "_");
            DownloadManager.Request r = new DownloadManager.Request(u);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "LeveX/" + name);
            DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            dm.enqueue(r);
            Toast.makeText(this, "Baixando em Downloads/LeveX", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível baixar", Toast.LENGTH_SHORT).show();
        }
    }

    /* ---------------- Utilidades ---------------- */

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }
}
